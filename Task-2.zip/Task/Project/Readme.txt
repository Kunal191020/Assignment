Steps to run the application
1-First go into abhishek 
2-run the django server
